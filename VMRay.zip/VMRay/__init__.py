"""
init.py

This module provides a set of functions for communicating with the Luminar
API. The main purpose of these functions is
to retrieve and process security indicators and leaked credentials from
Luminar, transform them into a compatible format
, and save them into Azure Sentinel.

Main components:

LuminarManager: This class manages interactions with the Luminar API. It is
responsible for requesting and refreshing
access tokens, as well as managing the connection status.

process_malware, enrich_malware_items, enrich_incident_items: These functions
process malware and incident items and
create enriched data for each.

create_data, get_static_data: These functions transform raw indicators into a
format compatible with Azure Sentinel.

luminar_api_fetch: This function fetches data from the Luminar API, processes
the fetched items, and manages
relationships between items.

main: This function handles Luminar API requests. It initializes the Luminar
manager, requests and refreshes access
tokens, manages Luminar API calls, and handles pagination to ensure all pages
of data are retrieved. A timer trigger
allows it to run at specified intervals.

This module is designed for use as part of an Azure Function App and requires
certain environment variables to be set.
"""

import re
import json
import time
import requests
import concurrent.futures
from ipaddress import ip_network
from os import environ
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, Generator, List, Optional, Tuple, Union
import logging
import azure.functions as func
from .state_manager import StateManager
from .utils import *

subscriptionID = environ.get("AzureSubscriptionID")
resourceGroupName = environ.get("AzureResourceGroupName")
workspaceName = environ.get("AzureWorkspaceName")
workspaceID = environ.get("WorkspaceID")
clientID = environ.get("AzureClientID")
clientSecret = environ.get("AzureClientSecret")
tenant_id = environ.get("AzureTenantID")
vmraySampleVerdict = environ.get("vmraySampleVerdict")
vmrayInitialFetchDate = environ.get("vmrayInitialFetchDate")
state = StateManager(environ.get("AzureWebJobsStorage"))
session = requests.Session()


TIMEOUT = 60.0
# There's a limit of 100 tiIndicators per request.
MAX_TI_INDICATORS_PER_REQUEST = 100
ENDPOINT = f"https://management.azure.com/subscriptions/{subscriptionID}/resourceGroups/{resourceGroupName}/providers/Microsoft.OperationalInsights/workspaces/{workspaceName}/providers/Microsoft.SecurityInsights/threatIntelligence/main/createIndicator?api-version=2024-03-01"
TOKEN_ENDPOINT = f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
VMRAY_BASE_URL = environ.get("vmrayBaseURL")
RESOURCE = "https://management.azure.com"

STIX_PARSER = re.compile(
    r"([\w-]+?):(\w.+?) (?:[!><]?=|IN|MATCHES|LIKE) '(.*?)' *[" r"OR|AND|FOLLOWEDBY]?"
)
IOC_MAPPING = {
    "file:hashes.'SHA-1'": "SHA1",
    "file:hashes.MD5": "MD5",
    "file:hashes.'SHA-256'": "SHA256",
    "file:hashes.'SHA-512'": "SHA512",
    "ipv4-addr": "IP",
    "file:name": "File_Extension",
    "file:size": "File_Size",
    "url": "URL",
    "email-addr": "EMAIL",
    "domain-name": "DOMAIN",
    "ipv6-addr": "IP",
    "mac-addr": "MAC",
    "directory": "DIR",
    "mutex": "MUTEX",
    "windows-registry-key": "WINDOWS_REGISTRY_KEY",
}

HEADERS = {
    "Content-Type": "application/x-www-form-urlencoded",
    "accept": "application/json",
}
AZURE_LOGIN_PAYLOAD = {
    "grant_type": "client_credentials",
    "client_id": clientID,
    "client_secret": clientSecret,
    "resource": RESOURCE,
}


def get_last_saved_timestamp(date_format="%Y-%m-%dT%H:%M:%S"):
    """
    This function retrieves the last saved timestamp from the state. If no
    timestamp is found, it returns 0.

    Parameters:
    date_format (str): The format in which the date and time are represented.
    Default is '%Y-%m-%d %H:%M:%S' which
    represents YYYY-MM-DD HH:MM:SS format.

    Returns:
    int: The timestamp of the last successful run of this function as a Unix
    timestamp. If the function is being run for
    the first time, it returns 0.
    """
    last_run_date_time = state.get()
    logging.debug("last saved time stamp is %s", last_run_date_time)

    return last_run_date_time if last_run_date_time else None


def save_checkpoint(timestamp: str, date_format: str = "%Y-%m-%dT%H:%M:%S") -> None:
    """
    This function saves the current UTC timestamp to the state.

    Parameters:
    date_format (str): The format in which the date and time are represented.
    Default is '%Y-%m-%dT%H:%M:%S'
                       which represents the format as YYYY-MM-DD HH:MM:SS.

    Returns:
    None
    """
    state.post(timestamp)


def get_access_token() -> Optional[str]:
    """
    This function fetches the access token from Sentinel.
    Returns:
    str: The access token if the request was successful, None otherwise.
    """
    try:
        response = session.post(
            TOKEN_ENDPOINT, data=AZURE_LOGIN_PAYLOAD, headers=HEADERS, timeout=TIMEOUT
        )
        response.raise_for_status()  # check if we got a HTTP error
        return response.json().get("access_token")
    except requests.HTTPError as http_err:
        logging.error("HTTP error occurred: %s", http_err)
        return None


# def save_sentinel_data(data: dict) -> None:
#     """
#     This function sends the data to Sentinel using an access token.
#     Parameters:
#     data (dict): The data to be sent to Sentinel.
#     Returns:
#     None
#     """
#     access_token = get_access_token()
#     if not access_token:
#         logging.error("Unable to retrieve access token")
#         return

#     headers = {"Authorization": f"Bearer {access_token}",
#                         "Content-Type": "application/json", "accept": "application/json"}

#     try:
#         response = session.post(ENDPOINT, headers=headers, json=data, timeout=TIMEOUT)
#         response.raise_for_status()  # check if we got a HTTP error
#     except requests.HTTPError as http_err:
#         logging.error("HTTP error occurred: %s", http_err)

def create_indicator(indicator_data):
        """To create indicator into Microsoft Sentinel."""
        try:
            logging.info(indicator_data)
            retry_count_429 = 0
            retry_count_401 = 0
            access_token = get_access_token()
            if not access_token:
                logging.error("Unable to retrieve access token")
                return
            while retry_count_429 <= 3 and retry_count_401 <= 1:
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer {}".format(access_token),
                }
                response = session.post(ENDPOINT, headers=headers, data=json.dumps(indicator_data), timeout=TIMEOUT)
                if response.status_code >= 200 and response.status_code <= 299:
                    response_json = response.json()
                    logging.info(f"Created the indicator into the sentinel with status code {response.status_code}")
                    return response_json
                elif response.status_code == 400:
                    logging.warning(f"error 400 for indicatorId {response.json()}")
                    return None

                elif response.status_code == 429:
                    logging.error("trying again error 429")
                    retry_count_429 += 1
                    time.sleep(60)
                elif response.status_code == 401:
                    logging.error("trying again error 401.")
                    bearer_token = get_access_token()
                    headers["Authorization"] = ("Bearer {}".format(bearer_token),)
                    retry_count_401 += 1
                else:
                    logging.error(f"status_code {response.status_code}")
                    raise Exception("Something went wrong")
            
            raise Exception("Max retries exceeded for microsoft sentinel.")
        except Exception:
            raise Exception("something")
        except Exception as error:
            raise Exception("Error generated while creating indicator")



# IndicatorTypes = {
#     "file:hashes.'SHA-1'": field_mapping,
#     "file:hashes.MD5": field_mapping,
#     "file:hashes.'SHA-256'": field_mapping,
#     "file:hashes.'SHA-512'": field_mapping,
#     "ipv4-addr": field_mapping,
#     "file:name": field_mapping,
#     "file:size": field_mapping,
#     "url": field_mapping,
#     "email-addr": field_mapping,
#     "domain-name": field_mapping,
#     "ipv6-addr": field_mapping,
#     "mac-addr": field_mapping,
#     "directory": field_mapping,
#     "mutex": field_mapping,
#     "windows-registry-key": field_mapping,
# }



def do_req(url, headres):
    response = requests.get(url=url, headers=headres)    
    if response.status_code == 429:
        time.sleep(1)
        do_req(url, headres)
    return response


def main(mytimer: func.TimerRequest) -> None:
    """
    Main function to handle VMRay API requests.

    This function initializes the VMRay manager, requests and refreshes
    access tokens, handles VMRay API calls,
    and handles pagination to ensure all pages of data are retrieved. It uses
    a timer trigger to run at specified
    intervals.

    :param mytimer: func.TimerRequest, timer for triggering the function at
    specified intervals.

    Note:
    - This function will log an error message and exit if an access token
    cannot be retrieved or refreshed.
    - If no more indicators are left to ingest, the function will log an
    informational message and stop iterating over
    the pages.
    - The function will save a timestamp after each run.
    """
    try:
        if mytimer.past_due:
            logging.info("The timer is past due!")
            return

        initial_date_time = get_last_saved_timestamp() or (datetime.now() - timedelta(days=int(vmrayInitialFetchDate))).strftime("%Y-%m-%dT00:00:00")
        # initial_date_time = (datetime.now() - timedelta(days=int(vmrayInitialFetchDate))).strftime("%Y-%m-%dT00:00:00")
        sample_verdict = vmraySampleVerdict
        current_date = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        submissions_list = utils.get_submission(sample_verdict, initial_date_time, current_date)
        # for submission in submissions_list:
        #     if submission.get('submission_finished'):
        #         sample_id = submission.get("submission_sample_id")
        #         sample_data = utils.get_sample(sample_id)
        #         iocs = utils.get_sample_ioc(sample_id)
        #         for key,value in iocs.items():
        #             if key in utils.IOC_LIST:
        #                 utils.IOC_MAPPING_FUNCTION[key](value, sample_id, submission.get('submission_id'), sample_verdict)
        headers = {
            "Authorization": f"api_key {utils.vmray_api_key}",
            "User-Agent": "Sentinel"
        }
        submission_dict = {}
        sample_ids = set()
        for sub in submissions_list:
            if sub.get('submission_finished'):
                sample_id = str(sub.get('submission_sample_id'))
                submission_dict.setdefault(sample_id, []).append(str(sub.get("submission_id")))
                sample_ids.add(sub.get("submission_sample_id"))
        # sample_ids = [submission.get("submission_sample_id") for submission in submissions_list if submission.get('submission_finished')]
        sample_ids = list(sample_ids)
        iocs_urls = [f'{utils.vmrayBaseURL}/rest/sample/{id}/iocs' for id in sample_ids]
        with concurrent.futures.ThreadPoolExecutor(max_workers=500) as executor:
            ioc_response = [executor.submit(do_req, url, headers) for url in iocs_urls]
            concurrent.futures.wait(ioc_response)
        ioc_response_dict = {}
        for i, s_id in enumerate(sample_ids):
            if ioc_response[i].result().status_code != 200:
                logging.error(f"Error in {s_id}: {ioc_response[i].result().json()}")
            else:
                json_response = ioc_response[i].result().json().get("data", {}).get('iocs', {})
                ioc_response_dict[str(s_id)] = json_response
        for sample, submission in submission_dict.items():
            iocs = ioc_response_dict.get(sample, {})
            for key, value in iocs.items():
                if key in utils.IOC_LIST:
                    utils.IOC_MAPPING_FUNCTION[key](value, int(sample), submission, sample_verdict)
        indicator_list = utils.indicator_list()
        logging.info(f"length of indiactor {len(indicator_list)}")
        # for indicator in indicator_list:
        #     create_indicator(indicator)
        with concurrent.futures.ThreadPoolExecutor(max_workers=500) as cre_executor:
            response = [cre_executor.submit(create_indicator, data) for data in indicator_list]
            concurrent.futures.wait(response)
        save_checkpoint(current_date)
    except Exception as ex: 
        logging.error(f"something went wrong. Error: {ex}")

