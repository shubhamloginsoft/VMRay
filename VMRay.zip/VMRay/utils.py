import requests
import logging
from os import environ
from typing import Dict, Union


FETCHED_ANALYSES_REPORTS = dict()
FETCHED_SAMPLE_IOCS = dict()
FETCHED_SAMPLE = dict()
FETCHED_SAMPLE_REPORTS = dict()
ANALYSIS_REPORT_XID = dict()

# IOC_LIST = ['domains', 'ips', 'urls', 'files', 'emails', 'registry']
IOC_LIST = ['domains', 'files']
RATING = {
    "malicious": '5.0',
    "suspicious": '3.0'
}
CONFIDENCE = {
    "malicious": '100',
    "suspicious": '75'
}
LOGS_STARTS_WITH = "VMRay Threat Intelligence"
INDICATOR_LIST = []

vmrayBaseURL = environ.get("vmrayBaseURL")
vmray_api_key = environ.get("vmrayAPIKey")

def do_request(endpoint, params, body={}):
    # import pdb; pdb.set_trace()
    headers = {
        "Authorization": f"api_key {vmray_api_key}",
        "User-Agent": "Sentinel"
    }

    try:
        response = requests.get(
            url=f'{vmrayBaseURL}/rest/{endpoint}',
            headers=headers,
            params=params
        )
        response.raise_for_status()  # Raises HTTPError for bad responses
        logging.info(f'User-Agent: {response.request.headers.get("User-Agent")}')
        return response
    except requests.exceptions.RequestException as e:
        logging.error(f"Error in request: {e}")
        logging.error(f"Error response: {response.json().get('error_msg')}")
        return response


def get_submission(verdict:str, from_time, to_time):
    """
        This function request submission api
        :param verdict: Submission verdict
        :param from_time: from_time
        :param to_time: to_time
        :return: submission list
    """
    submission_response = []
    #verdict = verdict.split("&")
    #logging.info(verdict)
    #for ver in verdict:
    params = {
        "submission_finish_time": f'{from_time}~{to_time}',
        "submission_verdict": verdict.lower(),
    }
    response = do_request("submission", params).json()
    submission_response.extend(response.get('data', []))
    while response.get('continuation_id'):
        response = do_request(f"continuation/{response.get('continuation_id')}", {}).json()
        submission_response.extend(response.get('data', []))
    return submission_response

def get_sample(id):
    """
    This function request sample api
    :param id:
    :return:
    """
    if not id in FETCHED_SAMPLE:
        sample_response = do_request(f'sample/{id}', {}).json().get("data", {})
        FETCHED_SAMPLE[id] = sample_response
        return sample_response
    return FETCHED_SAMPLE.get(id)


def get_sample_ioc(id):
    """
    This function request sample iocs api
    :param id: Sample ID
    :return: IOC dict
    """
    if not id in FETCHED_SAMPLE_IOCS:
        ioc_response = do_request(f'sample/{id}/iocs', {}).json().get("data", {}).get('iocs', {})
        FETCHED_SAMPLE_IOCS[id] = ioc_response
        return ioc_response
    return FETCHED_SAMPLE_IOCS.get(id)


def add_domain_indicator(domains, sample_id, submission_id, verdicts):
    """
    This function creates domain ioc in threat connect
    :param domains: domains list
    :param sample_xid: sample_xid
    :param sample_id: sample_id
    :param submission_id: submission_id
    :param verdicts: verdicts list
    :return: None
    """
    logging.info("adding domain ioc to batch")
    for domain in domains:
        verdict = domain.get('verdict')
        # if verdict.capitalize() in verdicts:
        pattern = f"[domain-name:value = '{domain.get('domain')}']"
        p_type = 'domain-name'
        data = get_static_data(domain, pattern, p_type, sample_id, submission_id, CONFIDENCE.get(verdict.lower(), 0))
        INDICATOR_LIST.append(data)

    return

def add_file_indicators(files, sample_id, submission_id, verdicts):
    """
        This function creates domain ioc in threat connect
        :param files: file list
        :param sample_xid: sample_xid
        :param sample_id: sample_id
        :param submission_id: submission_id
        :param verdicts: verdicts list
        :return: None
    """
    logging.info("adding file ioc to batch")
    for file in files:
        verdict = file.get('verdict')
        # if verdict.capitalize() in verdicts:
        file_summary_list = file.get('hashes', [])[0]
        md5 = file_summary_list.get('md5_hash')
        sha1 = file_summary_list.get('sha1_hash')
        sha256 = file_summary_list.get('sha256_hash')
        md5_pattern = f"[file:hashes.'SHA-MD5' = '{md5}']"
        sha1_pattern = f"[file:hashes.'SHA-1' = '{sha1}']"
        sha256_pattern = f"[file:hashes.'SHA-256' = '{sha256}']"
        data_md5 = get_static_data(file, md5_pattern, file.get('ioc_type'), sample_id, submission_id, CONFIDENCE.get(verdict.lower(), 0))
        data_sha1 = get_static_data(file, sha1_pattern, file.get('ioc_type'), sample_id, submission_id, CONFIDENCE.get(verdict.lower(), 0))
        data_sha256 = get_static_data(file, sha256_pattern, file.get('ioc_type'), sample_id, submission_id, CONFIDENCE.get(verdict.lower(), 0))
        INDICATOR_LIST.append(data_md5)
        INDICATOR_LIST.append(data_sha1)
        INDICATOR_LIST.append(data_sha256)
    return

# def add_ip_indicator(ips, sample_id, submission_id, verdicts):
#     """
#         This function creates domain ioc in threat connect
#         :param ips: ips list
#         :param sample_xid: sample_xid
#         :param sample_id: sample_id
#         :param submission_id: submission_id
#         :param verdicts: verdicts list
#         :return: None
#     """
#     logging.info("adding ip ioc to batch")
#     for ip in ips:
#         verdict = ip.get('verdict')
#         if verdict.capitalize() in verdicts:
#             description = (
#                 f"Type: {ip.get('type')}\n" if ip.get('type') else ""
#             )
#             analysis_ids = ip.get('analysis_ids', [])
#             current_ip = batch.indicator('Address', ip.get('ip_address'), rating=RATING[verdict.lower()],
#                                                 confidence=CONFIDENCE[verdict.lower()])
#             create_tag(current_ip, ip.get("protocols", []))
#             create_tag(current_ip, ip.get("country", ""))
#             current_ip.attribute("Description", description)
#             current_ip.attribute("VMRay Sample ID", sample_id)
#             current_ip.attribute("VMRay Submission ID", submission_id)
#     return

# def add_email_indicator(emails, sample_id, submission_id, verdicts):
#     """
#         This function creates emails ioc in threat connect
#         :param emails: email list
#         :param sample_xid: sample_xid
#         :param sample_id: sample_id
#         :param submission_id: submission_id
#         :param verdicts: verdicts list
#         :return: None
#     """
#     logging.info("adding email ioc to batch")
#     for email in emails:
#         verdict = email.get('verdict')
#         if verdict.capitalize() in verdicts:
#             description = (
#                 f"Type: {email.get('type', '')}" if email.get('type') else ""
#             )
#             analysis_ids = email.get('analysis_ids', [])
#             current_email = batch.indicator('Email Subject', email.get('subject'))
#             create_tag(current_email, email.get('classifications'))
#             current_email.attribute("Description", description)
#             current_email.attribute("VMRay Sample ID", sample_id)
#             current_email.attribute("VMRay Submission ID", submission_id)
#     return

# def add_email_sub_indicator(sample_xid, email_subject):
#     email_sub = batch.indicator('Email Subject', email_subject)
#     email_sub.association(sample_xid)
#     return

# def add_url_indicator(urls, sample_id, submission_id, verdicts):
#     """
#         This function creates urls ioc in threat connect
#         :param urls: url list
#         :param sample_xid: sample_xid
#         :param sample_id: sample_id
#         :param submission_id: submission_id
#         :param verdicts: verdicts list
#         :return: None
#     """
#     logging.info("adding url ioc to batch")
#     for url in urls:
#         verdict = url.get('verdict')
#         if verdict.capitalize() in verdicts:
#             description = (
#                 f"Type: {url.get('type')}" if url.get('type') else ""
#             )
#             analysis_ids = url.get('analysis_ids', [])
#             current_url = batch.indicator('URL', url.get('url'), rating=RATING[verdict.lower()],
#                                                 confidence=CONFIDENCE[verdict.lower()])
#             create_tag(current_url, url.get("countries", []))
#             current_url.attribute('Description', description)
#             current_url.attribute("VMRay Sample ID", sample_id)
#             current_url.attribute("VMRay Submission ID", submission_id)
#     return

# def add_registry_indicator(registries, sample_id, submission_id, verdicts):
#     """
#         This function creates registry ioc in threat connect
#         :param registries: registry list
#         :param sample_xid: sample_xid
#         :param sample_id: sample_id
#         :param submission_id: submission_id
#         :param verdicts: verdicts list
#         :return: None
#     """
#     logging.info("adding registry ioc to batch")

#     for registry in registries:
#         verdict = registry.get('verdict')
#         if verdict.capitalize() in verdicts:
#             description = (
#                 f"Type: {registry.get('type', '')}"
#             )
#             analysis_ids = registry.get('analysis_ids', [])
#             key_name, value_name = "", ""
#             if registry.get('reg_key_name'):
#                 key_name, value_name = registry.get('reg_key_name').split('\\', 1)
#             value_type = registry.get('reg_key_value_types')[0] if registry.get('reg_key_value_types') else ""
#             current_registry = batch.registry_key(key_name, value_name, value_type)
#             current_registry.rating = RATING[verdict.lower()]
#             current_registry.confidence = CONFIDENCE[verdict.lower()]
#             create_tag(current_registry, registry.get('classifications', []))
#             create_tag(current_registry, registry.get("sources", []))
#             current_registry.attribute('Additional Analysis and Context',
#                                         f"VTIs: {', '.join(registry.get('vtis', []))}")
#             current_registry.attribute("VMRay Sample ID", sample_id)
#             current_registry.attribute("VMRay Submission ID", submission_id)
#             current_registry.attribute('Description', description)
#     return

def get_static_data(
    indicator, pattern, type, sample_id, submission_id, confidence
) -> Dict[str, Union[str, int, list]]:
    """
    Generate static data dictionary based on the input indicator and value.

    Parameters:
    indicator (Dict[str, Union[str, int, list, Dict[str, Any]]]): A
    dictionary containing
    indicator information.
    value (str): A string value indicating the type of the indicator.

    Returns:
    Dict[str, Union[str, int, list]]: A dictionary of static data.
    """
    data = {
            "kind": "indicator",
            "properties": {
                "source": "VMRay Threat Intelligence",
                "threatIntelligenceTags": [
                    sample_id, submission_id
                ],
                "displayName": f"VMRay Threat Intelligence {indicator.get('id')}",
                "confidence": confidence,
                "createdByRef": "VMRay",
                "description": "debugging indicators",
                "externalReferences": [],
                "granularMarkings": [],
                "threatTypes": ", ".join(indicator.get('threat_names', [])),
                "killChainPhases": [],
                "labels": [],
                "modified": "",
                "pattern": str(pattern),
                "patternType": type,
                "revoked": False,
                "validFrom": "2020-04-15T17:44:00.114052Z",
                "validUntil": ""
            }
        }
    return data


IOC_MAPPING_FUNCTION = {
            'domains': add_domain_indicator,
            # 'ips': add_ip_indicator,
            # 'urls': add_url_indicator,
            'files': add_file_indicators
            # 'registry': add_registry_indicator,
            # 'emails': add_email_indicator
        }

def indicator_list():
    return INDICATOR_LIST
