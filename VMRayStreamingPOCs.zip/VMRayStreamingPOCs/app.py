import logging
import json
import azure.functions as func

def main(myblob: func.InputStream):
    logging.info(f"Processing blob: {myblob.name}, Size: {myblob.length} bytes")

    try:
        blob_bytes = myblob.read()
        blob_text = blob_bytes.decode('utf-8')
        data = json.loads(blob_text)

        for record in data.get('records', []):
            alert_id = record.get('AlertId') or record.get('alertId')
            if alert_id:
                logging.info(f"Alert ID: {alert_id}")

    except Exception as e:
        logging.error(f"Error processing blob {myblob.name}: {e}")

