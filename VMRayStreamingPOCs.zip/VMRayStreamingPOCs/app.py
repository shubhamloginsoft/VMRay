import os
import json
import logging
import azure.functions as func

from azure.data.tables import TableServiceClient
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError

TABLES_CONN_STR  = os.getenv("AzureWebJobsStorage")
CHECKPOINT_TABLE = os.getenv("CHECKPOINT_TABLE", "AlertCheckpoints")

_table_client = TableServiceClient.from_connection_string(TABLES_CONN_STR).get_table_client(CHECKPOINT_TABLE)
try:
    _table_client.create_table()
except ResourceExistsError:
    pass

def hour_key_from_path(blob_name: str) -> str:
    """
    Build a stable hour key from Defender partitions in the blob path.
    Example blob path parts: y=2025/m=08/d=14/h=10/...
    Returns: 'y=2025_m=08_d=14_h=10'
    """
    parts = []
    for p in blob_name.split("/"):
        lp = p.lower()
        if lp.startswith(("y=","m=","d=","h=")):
            parts.append(p)
    return "_".join(parts) if parts else "unknown_hour"

def seen(partition_key: str, alert_id: str) -> bool:
    """Check if AlertId already recorded for this hour partition."""
    try:
        _table_client.get_entity(partition_key=partition_key, row_key=alert_id)
        return True
    except ResourceNotFoundError:
        return False

def mark_seen(partition_key: str, alert_id: str) -> None:
    """Record AlertId as processed."""
    _table_client.upsert_entity({"PartitionKey": partition_key, "RowKey": alert_id})

def main(myblob: func.InputStream):
    logging.info(f"Processing blob: {myblob.name}  size={myblob.length} bytes")

    hour_key = hour_key_from_path(myblob.name)
    text = myblob.read().decode("utf-8", errors="replace")

    new_count = seen_count = 0
    lines = text.splitlines()

    for line in lines:
        line = line.strip()
        if not line:
            continue

        try:
            obj = json.loads(line)
        except json.JSONDecodeError as e:
            logging.error(f"Bad JSON line skipped: {e}")
            continue

        props = obj.get("properties", obj)
        alert_id = (
            props.get("AlertId")
            or props.get("alertId")
            or obj.get("AlertId")
            or obj.get("alertId")
        )
        if not alert_id:
            # Optional: log once for debugging unusual shapes
            continue

        if seen(hour_key, alert_id):
            seen_count += 1
        else:
            logging.info(f"NEW AlertId: {alert_id}")
            mark_seen(hour_key, alert_id)
            new_count += 1

    logging.info(f"Done for {hour_key}: {new_count} new, {seen_count} already seen")

