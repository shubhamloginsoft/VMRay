import logging
import json
import azure.functions as func

def main(myblob: func.InputStream):
    logging.info(f"Processing blob: {myblob.name}, Size: {myblob.length} bytes")

    try:
        blob_text = myblob.read().decode('utf-8')

        for line in blob_text.strip().splitlines():
            if not line.strip():
                continue
            try:
                data = json.loads(line)
                properties = data.get("properties", {})
                alert_id = properties.get("AlertId")
                if alert_id:
                    logging.info(f"Alert ID: {alert_id}")
                else:
                    logging.warning(f"No AlertId found in blob: {myblob.name}")
            except json.JSONDecodeError as e:
                logging.error(f"Failed to parse JSON line: {e}")

    except Exception as e:
        logging.error(f"Error processing blob {myblob.name}: {e}")

