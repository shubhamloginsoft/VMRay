import logging
import json
import azure.functions as func
from azure.storage.blob import BlobServiceClient
import os

# Environment variables for storage
STORAGE_CONNECTION_STRING = os.environ["AzureWebJobsStorage"]
CHECKPOINT_CONTAINER = "function-checkpoints"

def load_checkpoint(hour_key):
    """Load processed Alert IDs for the specific hour from checkpoint blob."""
    try:
        blob_service_client = BlobServiceClient.from_connection_string(STORAGE_CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(CHECKPOINT_CONTAINER)
        
        # Ensure container exists
        try:
            container_client.create_container()
        except Exception:
            pass

        checkpoint_blob_name = f"{hour_key}_processed_alert_ids.json"
        blob_client = container_client.get_blob_client(checkpoint_blob_name)
        
        if blob_client.exists():
            data = blob_client.download_blob().readall()
            return set(json.loads(data.decode('utf-8')))
        return set()
    except Exception as e:
        logging.warning(f"Checkpoint load failed for {hour_key}: {e}")
        return set()

def save_checkpoint(hour_key, alert_ids):
    """Save processed Alert IDs for the specific hour to checkpoint blob."""
    try:
        blob_service_client = BlobServiceClient.from_connection_string(STORAGE_CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(CHECKPOINT_CONTAINER)
        
        try:
            container_client.create_container()
        except Exception:
            pass
        
        checkpoint_blob_name = f"{hour_key}_processed_alert_ids.json"
        container_client.upload_blob(
            checkpoint_blob_name,
            json.dumps(list(alert_ids)),
            overwrite=True
        )
    except Exception as e:
        logging.warning(f"Checkpoint save failed for {hour_key}: {e}")

def main(myblob: func.InputStream):
    logging.info(f"Processing blob: {myblob.name}, Size: {myblob.length} bytes")

    try:
        # Extract hour key (example: h=2025_hh=08)
        parts = myblob.name.split("/")
        hour_parts = [p for p in parts if p.startswith("h=") or p.startswith("hh=")]
        hour_key = "_".join(hour_parts) if hour_parts else "unknown_hour"

        processed_ids = load_checkpoint(hour_key)
        new_ids_found = False

        blob_text = myblob.read().decode('utf-8')

        for line in blob_text.strip().splitlines():
            if not line.strip():
                continue
            try:
                data = json.loads(line)
                properties = data.get("properties", data)
                alert_id = properties.get("AlertId") or data.get("alertId")
                if alert_id and alert_id not in processed_ids:
                    logging.info(f"NEW Alert ID: {alert_id}")
                    processed_ids.add(alert_id)
                    new_ids_found = True
                elif not alert_id:
                    logging.warning(f"No AlertId found in blob: {myblob.name}")
            except json.JSONDecodeError as e:
                logging.error(f"Failed to parse JSON line: {e}")

        if new_ids_found:
            save_checkpoint(hour_key, processed_ids)
        else:
            logging.info(f"No new Alert IDs found for {hour_key}.")

    except Exception as e:
        logging.error(f"Error processing blob {myblob.name}: {e}")

