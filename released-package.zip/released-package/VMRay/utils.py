import requests
import re
import time
import json
import logging
import uuid
from os import environ
from typing import Dict, Union
from datetime import datetime, timezone

FETCHED_SAMPLE_IOCS = dict()
FETCHED_SAMPLE = dict()

IOC_LIST = ['domains', 'ips', 'urls', 'files']
RETRY_STATUS_CODE = [500, 501, 502, 503, 504, 429]
RATING = {
    "malicious": '5.0',
    "suspicious": '3.0'
}
CONFIDENCE = {
    "malicious": '100',
    "suspicious": '75'
}

USER_AGENT = "VMRayThreatIntelligenceSentinel:1.0.0"

INDICATOR_LIST = []
ipv4Regex = r'^(?P<ipv4>(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))[:]?(?P<port>\d+)?$'
ipv6Regex = r'^(?:(?:[0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:(?:(:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$'  # noqa: E501

vmrayBaseURL = environ.get("VmrayBaseURL")
vmray_api_key = environ.get("VmrayAPIKey")


def is_json(response):
    """Checks if response is jsonable

    Args:
        response (requests.Response):

    Returns:
        bool: true if object is jsonable
    """
    try:
        response.json()
    except ValueError:
        return False
    return True


def do_request(endpoint, params, max_retries=3, delay=1):
    headers = {
        "Authorization": f"api_key {vmray_api_key}",
        "User-Agent": USER_AGENT
    }
    retry_429 = 0
    while retry_429 < max_retries:
        try:
            response = requests.get(
                url=f'{vmrayBaseURL}/rest/{endpoint}',
                headers=headers,
                params=params
            )
            if not is_json(response):
                raise ValueError
            response.raise_for_status()  # Raises HTTPError for bad responses
            return response
        except requests.HTTPError as herr:
            if response.status_code in RETRY_STATUS_CODE:
                logging.error(f"Error response: {response.json().get('error_msg')}")
                logging.info(f"Retrying ({retry_429 + 1}/{max_retries}) due to {response.json()}")
                time.sleep(delay)
                retry_429 += 1
                continue
            else:
                logging.error(f"Error response: {response.json().get('error_msg')}")
                return response
        except ValueError as verr:
            logging.error(f"Error in VMRay request: {verr}")
            logging.error(f"Error response {response.status_code}: {response.text}")
            return json.dumps({})
        except Exception as err:
            logging.error(f"Error in request: {err}")


def get_submission(verdict, from_time, to_time):
    """
        This function request submission api
        :param verdict: Submission verdict
        :param from_time: from_time
        :param to_time: to_time
        :return: submission list
    """
    submission_response = []
    logging.info(f'User-Agent: {USER_AGENT}')
    logging.info(f'Fetching submission from {from_time}~{to_time}')
    for ver in verdict:
        params = {
            "submission_finish_time": f'{from_time}~{to_time}',
            "submission_verdict": ver.strip().lower(),
        }
        response = do_request("submission", params).json()
        submission_response.extend(response.get('data', []))
        while response.get('continuation_id'):
            response = do_request(f"continuation/{response.get('continuation_id')}", {}).json()
            submission_response.extend(response.get('data', []))
    return submission_response


def get_sample(id):
    """
    This function request sample api
    :param id:
    :return:
    """
    if not id in FETCHED_SAMPLE:
        sample_response = do_request(f'sample/{id}', {}).json().get("data", {})
        FETCHED_SAMPLE[id] = sample_response
        return sample_response
    return FETCHED_SAMPLE.get(id)


def get_sample_ioc(id):
    """
    This function request sample iocs api
    :param id: Sample ID
    :return: IOC dict
    """
    if not id in FETCHED_SAMPLE_IOCS:
        ioc_response = do_request(f'sample/{id}/iocs', {}).json().get("data", {}).get('iocs', {})
        FETCHED_SAMPLE_IOCS[id] = ioc_response
        return ioc_response
    return FETCHED_SAMPLE_IOCS.get(id)


def add_domain_indicator(domains, sample_id, submission_id, verdicts):
    """
    This function creates domain ioc in threat connect
    :param domains: domains list
    :param sample_id: sample_id
    :param submission_id: submission_id
    :param verdicts: verdicts list
    :return: None
    """
    for domain in domains:
        verdict = domain.get('verdict')
        if verdict.capitalize() in verdicts:
            domain_pattern = f"[domain-name:value = '{domain.get('domain')}']"
            domain_name = domain.get("domain", "")
            unique_id = gen_unique_id("domain", domain_name)
            data = get_static_data(unique_id, domain, domain_pattern, sample_id, submission_id, domain_name,
                                   CONFIDENCE.get(verdict.lower(), 0))
            INDICATOR_LIST.append(data)

    return


def add_file_indicators(files, sample_id, submission_id, verdicts):
    """
        This function creates domain ioc in threat connect
        :param files: file list
        :param sample_id: sample_id
        :param submission_id: submission_id
        :param verdicts: verdicts list
        :return: None
    """
    for file in files:
        verdict = file.get('verdict')
        if verdict.capitalize() in verdicts:
            file_summary_list = file.get('hashes', [])[0]
            md5 = file_summary_list.get('md5_hash')
            sha1 = file_summary_list.get('sha1_hash')
            sha256 = file_summary_list.get('sha256_hash')
            md5_pattern = f"[file:hashes.'MD5' = '{md5}']"
            sha1_pattern = f"[file:hashes.'SHA-1' = '{sha1}']"
            sha256_pattern = f"[file:hashes.'SHA-256' = '{sha256}']"
            filename = file.get("filename", "")
            unique_md5_id = gen_unique_id("file", md5)
            unique_sha256_id = gen_unique_id("file", sha256)
            unique_sha1_id = gen_unique_id("file", sha1)
            data_md5 = get_static_data(unique_md5_id, file, md5_pattern, sample_id, submission_id, filename or md5,
                                       CONFIDENCE.get(verdict.lower(), 0))
            data_sha1 = get_static_data(unique_sha1_id, file, sha1_pattern, sample_id, submission_id, filename or sha1,
                                        CONFIDENCE.get(verdict.lower(), 0))
            data_sha256 = get_static_data(unique_sha256_id, file, sha256_pattern, sample_id, submission_id, filename or sha256,
                                          CONFIDENCE.get(verdict.lower(), 0))
            INDICATOR_LIST.append(data_md5)
            INDICATOR_LIST.append(data_sha1)
            INDICATOR_LIST.append(data_sha256)
    return


def get_utc_time():
    # Get current time in UTC
    current_time = datetime.now(timezone.utc)

    # Format the current time with milliseconds and UTC timezone
    formatted_time = current_time.strftime('%Y-%m-%dT%H:%M:%S.') + f'{current_time.microsecond // 1000:03d}Z'
    return formatted_time


def check_ip(ip):
    if re.match(ipv4Regex, ip):
        return 'ipv4-addr'
    elif re.match(ipv6Regex, ip):
        return 'ipv6-addr'
    else:
        return None


def add_ip_indicator(ips, sample_id, submission_id, verdicts):
    """
        This function creates domain ioc in threat connect
        :param ips: ips list
        :param sample_id: sample_id
        :param submission_id: submission_id
        :param verdicts: verdicts list
        :return: None
    """
    for ip in ips:
        verdict = ip.get('verdict')
        if verdict.capitalize() in verdicts:
            ip_add = ip.get("ip_address", "")
            ip_type = check_ip(ip_add)
            if ip_type:
                ip_pattern = f"[{ip_type}:value = '{ip_add}']"
                unique_id = gen_unique_id("ip", ip_add)
                data = get_static_data(unique_id, ip, ip_pattern, sample_id, submission_id, ip_add,
                                       CONFIDENCE.get(verdict.lower(), 0))
                INDICATOR_LIST.append(data)
    return


def add_url_indicator(urls, sample_id, submission_id, verdicts):
    """
        This function creates urls ioc in threat connect
        :param urls: url list
        :param sample_id: sample_id
        :param submission_id: submission_id
        :param verdicts: verdicts list
        :return: None
    """
    for url in urls:
        verdict = url.get('verdict')
        if verdict.capitalize() in verdicts:
            url_name = url.get("url", "")
            url_pattern = f"[url:value = '{url_name}']"
            unique_id = gen_unique_id("url", url_name)
            data = get_static_data(unique_id, url, url_pattern, sample_id, submission_id, url_name,
                                   CONFIDENCE.get(verdict.lower(), 0))
            INDICATOR_LIST.append(data)
    return


def gen_unique_id(indicator_type: str, indicator_value: str, threat_source: str = "VMRay"):
    """
    Generate a unique identifier for a threat indicator.

    This function creates a unique identifier by combining an indicator type, an indicator_value,
    and a threat source. It ensures that the identifier is consistent and uniquely represents
    the combination of these inputs.

    Parameters:
        indicator_type: str
            'file', 'email', 'domain', 'url', etc.
        indicator_value: str
           a hash, IP address, domain name, or STIX pattern.
        threat_source: str, optional
            namespace to isolate ID generation per source/system".

    Returns:
        str
            A generated unique identifier string that combines the input information.
    """
    custom_namespace = uuid.uuid5(uuid.NAMESPACE_DNS, threat_source)
    name_string = f"{indicator_type}:{indicator_value}"
    indicator_uuid = uuid.uuid5(custom_namespace, name_string)
    return f"indicator--{indicator_uuid}"


def get_static_data(
        unique_uuid, indicator, pattern, sample_id, submission_id, name, confidence
) -> Dict[str, Union[str, int, list]]:
    """
    Generate a static data dictionary for an indicator based on provided parameters.

    This function constructs a dictionary containing detailed information about
    an indicator, formatted according to a specific schema. It incorporates multiple
    fields including metadata, references, labels, and pattern-related data. The function
    also sanitizes the input data where necessary.

    Parameters:
        unique_uuid (Str): A unique identifier for the indicator, used as the primary key.
        indicator (dict): A dictionary holding information about the indicator,
            including fields such as `analysis_ids`, `categories`, `classifications`,
            `threat_names`, and `ioc_type`.
        pattern (str): A string representing the indicator pattern, used for
            defining the indicator's matching conditions.
        sample_id (str): The unique identifier for the sample associated with the indicator.
        submission_id (str): The unique identifier for the submission associated
            with the indicator.
        name (str): A descriptive name for the indicator.
        confidence (int): An integer value representing the computation of the confidence
            level associated with the indicator.

    Returns:
        dict: A dictionary containing the structured data for the indicator, including
            fields for type, specification version, identifier, timestamps, and external
            references.
    """
    analysis = ", ".join(map(str, indicator.get("analysis_ids", [])))
    categories = ", ".join(indicator.get("categories", []))
    classifications = ", ".join(indicator.get("classifications", []))
    threat_names = indicator.get("threat_names", [])
    t_type = []
    for threat in threat_names:
        if re.match(r'^[a-zA-Z0-9\s]+$', threat):
            t_type.append(threat)
    tags = [f"sample_id: {sample_id}", f"submission_id: {submission_id}", f"threat_names: {', '.join(t_type)}",
            f"Classifications: {classifications}"]

    data = {
        "type": "indicator",
        "spec_version": "2.1",
        "id": unique_uuid,
        "created": get_utc_time(),
        "modified": get_utc_time(),
        "revoked": False,
        "labels": tags,
        "confidence": confidence,
        "external_references": [
            {
                "source_name": "VMRay Threat Intelligence",
                "description": f"Sample ID {sample_id}\nSubmission ID {submission_id}",
                "url": f'{vmrayBaseURL}/sample/{sample_id}#summary',
            }
        ],
        "name": name,
        "description": f"Sample URL: {vmrayBaseURL}/sample/{sample_id}#summary,\nAnalysis IDs: {analysis},\nCategories: {categories}",
        "indicator_types": [indicator.get('ioc_type', "")],
        "pattern": pattern,
        "pattern_type": "stix",
        "pattern_version": "2.1",
        "valid_from": get_utc_time(),
    }
    return data


IOC_MAPPING_FUNCTION = {
    'domains': add_domain_indicator,
    'ips': add_ip_indicator,
    'urls': add_url_indicator,
    'files': add_file_indicators
}


def indicator_list():
    return INDICATOR_LIST
